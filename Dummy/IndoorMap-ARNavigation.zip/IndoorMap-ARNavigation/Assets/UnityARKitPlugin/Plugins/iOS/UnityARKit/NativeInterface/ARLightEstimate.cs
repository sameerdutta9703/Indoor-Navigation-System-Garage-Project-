﻿using System;

namespace UnityEngine.XR.iOS
{
	public struct ARLightEstimate
	{
		public double ambientIntensity;
	}
}

