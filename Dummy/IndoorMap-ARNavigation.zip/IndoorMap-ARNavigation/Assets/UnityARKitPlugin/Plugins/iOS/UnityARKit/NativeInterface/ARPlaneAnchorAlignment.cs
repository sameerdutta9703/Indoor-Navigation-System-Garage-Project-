﻿using System;

namespace UnityEngine.XR.iOS
{
	public enum ARPlaneAnchorAlignment : long
	{
		/** A plane that is horizontal with respect to gravity. */
		ARPlaneAnchorAlignmentHorizontal
	}
}

