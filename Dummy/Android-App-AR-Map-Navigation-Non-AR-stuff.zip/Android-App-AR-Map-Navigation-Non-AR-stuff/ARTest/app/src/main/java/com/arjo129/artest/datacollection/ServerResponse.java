package com.arjo129.artest.datacollection;

public enum ServerResponse {
    SERVER_RESPONSE_OK,
    SERVER_RESPONSE_BAD_AUTH,
    SERVER_RESPONSE_ERROR
}
