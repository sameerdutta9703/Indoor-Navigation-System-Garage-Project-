package com.arjo129.artest.arrendering;

public class StairException extends Exception {
}
