package com.arjo129.artest.places;

/**
 * Done by Chelsey
 */
public enum Connector {
    Lift,
    Stairs
}
